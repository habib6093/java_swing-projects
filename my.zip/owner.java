import javafx.application.Application;
import javafx.event.*;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import java.io.File;//for css //
import javafx.geometry.Pos; //for positioning//
import javafx.scene.control.*;
import javafx.scene.text.*;
import javafx.event.ActionEvent;
import javafx.stage.Stage;
import java.sql.*;



public class owner
{

  


   public void starts(Stage stage_ob)
   {          System.out.println("hy guys this is habib");
            StackPane stackPane_ob=new StackPane();
            stackPane_ob.setAlignment(Pos.CENTER);

            Scene scene_ob=new Scene(stackPane_ob,1280,620);
          
           
           //..connect css file//
         	File f = new File("app.css");
       
            stackPane_ob.getStylesheets().add("file:///" + f.getAbsolutePath().replace("\\", "/"));



               

            Text t=new Text("hey owner you are none but a god damn motherfucker....");
             stackPane_ob.getChildren().add(t);
             stackPane_ob.setId("owner");
            t.setId("log_label");

            
           stage_ob.setResizable(false);
           stage_ob.setScene(scene_ob);
           stage_ob.show();


   }



}