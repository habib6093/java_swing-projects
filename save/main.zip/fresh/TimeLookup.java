public class Hello
{
  public static void main(String arc[])
  {
    double x=System.currentTimeMillis();
  }
}