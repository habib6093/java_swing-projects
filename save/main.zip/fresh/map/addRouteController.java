import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class addRouteController {
	@FXML
	Button home = new Button(); 	
	
	
	
	@FXML
	TextField to = new TextField();

	@FXML
	TextField from = new TextField();


	@FXML 
	Label message = new Label(); 

	@FXML 
	Label success = new Label();

	@FXML	
	public void Routing (ActionEvent e) throws Exception {
		Parent root;
		Stage stage;
		
		if(e.getSource() == home){
		    stage = (Stage) home.getScene().getWindow();
			root = FXMLLoader.load(getClass().getResource("route.fxml"));
			Scene scene = new Scene(root,1280,720);
			scene.getStylesheets().add(getClass().getResource("app.css").toExternalForm());
			stage.setScene(scene);		
		} 	
	}

	@FXML
	public void formSubmission(ActionEvent e){
		if(to.getText().equals("") == false){
			if(from.getText().equals("") == false){
				System.out.println(to.getText());
				System.out.println(from.getText());
				message.setText("");
				success.setText("Sucess!!");	
			} else {
				success.setText("");
				message.setText("*From must be filled");	
			}
		} else {
			success.setText("");
			message.setText("*To must be filled");
		}
	}	
}
