import javafx.application.Application;
import javafx.event.*;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import java.io.File;//for css //
import javafx.geometry.Pos; //for positioning//
import javafx.scene.control.*;
import javafx.scene.text.*;
import javafx.event.ActionEvent;
import javafx.stage.Stage;
import java.sql.*;
import javafx.fxml.FXMLLoader;


import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;




public class token extends Application
{
  public static void main(String arc[])
  {
     launch(arc);
  }


  public void start(Stage stage_ob) throws Exception
  {

    Parent parent_ob;
          //stackPane_ob.setAlignment(Pos.CENTER);

          Scene scene_ob=new Scene(parent_ob,1280,620);
          
           
           //..connect css file//
        File f = new File("app.css");
       
          parent_ob.getStylesheets().add("file:///" + f.getAbsolutePath().replace("\\", "/"));
         String seat_number="C2";
         String token_number="C2-10345-08";//seat number_busno_last digit of mobile no...
         int fair=400;
		 
		 Button print=new Button("Print");
		 Button home=new Button("Home");

         Text t=new Text("Successfull ........");
         Text t1=new Text("Seat number: "+seat_number);
         
         Text t2=new Text("Route: Dhaka to Chittagong");
         Text t3=new Text("Departure time:11-8-2016 11.30 ");

         Text t4=new Text("Token number: c2-1130-1-2");//seat_no-time-bus_id-route_id
         Text t5=new Text("To confirm your seat,,pay taka 400");

       //   ComboBox<String> myComboBox = new ComboBox<String>();
          //myComboBox.setPrototypeDisplayValue("XXXXXXXXXXXXXXXXXX");

       //   myComboBox.getItems().addAll("BKASH","Datch-Bangla bank","Sonali bank","Bangladesh bank","AIUB");
         // myComboBox.setPreferredSize(new Dimension(10,20));

         // myComboBox.setEditable(true); 

          t.setTranslateX(0);
          t.setTranslateY(-190);

          t1.setTranslateX(-20);
          t1.setTranslateY(-100);

          t2.setTranslateX(-20);
          t2.setTranslateY(-60);

          t3.setTranslateX(-20);
          t3.setTranslateY(-20);

          t4.setTranslateX(-20);
          t4.setTranslateY(20);

          t5.setTranslateX(-20);
          t5.setTranslateY(60);
		  
		  print.setTranslateX(-80);
		  print.setTranslateY(150);
		  
		  
		  home.setTranslateX(30);
		  home.setTranslateY(150);
		  
		  print.setId("button");
		  home.setId("button");

          //stackPane_ob.getChildren().add(t);
          //stackPane_ob.getChildren().add(t1);
          //stackPane_ob.getChildren().add(t2);
         // stackPane_ob.getChildren().add(t3);
         // stackPane_ob.getChildren().add(t4);
          //stackPane_ob.getChildren().add(t5);
		  //stackPane_ob.getChildren().add(print);
		  parent_ob.getChildren().add(home);
        //  stackPane_ob.getChildren().add(t4);
         // stackPane_ob.getChildren().add(myComboBox);

           t.setId("log_label");
           t1.setId("info");
           t2.setId("info");
           t3.setId("info");
           t4.setId("info");
           t5.setId("info");



           //stackPane_ob.setId("login");
		   
		   
		   
		   home.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
				
				System.out.println("home....");
				
				parent_ob=FXMLLoader.load(getClass().getResource("\route.fxml"));
				
			}
			});
         //  myComboBox.setId("drop");
           stage_ob.setResizable(false);
           stage_ob.setScene(parent_ob);
           stage_ob.show();

  }
}